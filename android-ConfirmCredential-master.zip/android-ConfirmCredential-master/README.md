
Android Confirm Credential Sample
=================================

This sample has been deprecated/archived meaning it's read-only and it's no longer actively maintained (more details on archiving can be found [here][1]).

For other related samples, check out the new [github.com/android/security-samples][2] repo. Thank you!

[1]: https://help.github.com/en/articles/about-archiving-repositories
[2]: https://github.com/android/security-samples
